package com.tddJunit.java;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MathsTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
